jQuery(function () {
	jQuery('div.order-comments').hide();

	jQuery('a.order-comments-link').on('click', function (e) {
			e.preventDefault();
			jQuery(this).next('div').slideToggle();
	});
});