<?php
define('WCMp_PLUGIN_TOKEN', 'wcmp');

define('WCMp_TEXT_DOMAIN', 'WCMp');

define('WCMp_PLUGIN_VERSION', '2.4.9');

define('WCMP_SCRIPT_DEBUG', false);
?>
